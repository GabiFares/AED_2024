public class Temperature {

  public float fahrenheitTemp = 70.8f; 
  

  public void calculateCelsius() {

  System.out.println((fahrenheitTemp - 32) * 5 / 9);
        
  }// end display method
    
}//end class
