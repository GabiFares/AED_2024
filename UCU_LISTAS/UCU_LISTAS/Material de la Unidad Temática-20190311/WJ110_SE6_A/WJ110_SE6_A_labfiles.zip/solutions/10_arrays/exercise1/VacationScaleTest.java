public class VacationScaleTest {
   
  public static void main (String args[]) {
 
  VacationScale myVacationScale = new VacationScale();
  
  myVacationScale.setVacationScale();

  myVacationScale.displayVacationDays(2);
  myVacationScale.displayVacationDays(4);
  myVacationScale.displayVacationDays(10);
  } 
}
