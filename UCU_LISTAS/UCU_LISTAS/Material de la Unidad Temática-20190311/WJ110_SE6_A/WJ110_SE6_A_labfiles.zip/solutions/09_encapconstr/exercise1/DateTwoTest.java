public class DateTwoTest {

  public static void main(String args[]) {
          
    DateTwo d = new DateTwo();
    d.day = 17;
    d.month = 9;
    d.year = 1995;

    System.out.println(d.day + " " + d.month + " " + d.year);

  }// end main
    
} // end class

