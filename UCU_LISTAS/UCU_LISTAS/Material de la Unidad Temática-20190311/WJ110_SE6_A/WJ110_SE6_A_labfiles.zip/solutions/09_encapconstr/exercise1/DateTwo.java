public class DateTwo {

    private int day;
    private int month;
    private int year;

} //end class
