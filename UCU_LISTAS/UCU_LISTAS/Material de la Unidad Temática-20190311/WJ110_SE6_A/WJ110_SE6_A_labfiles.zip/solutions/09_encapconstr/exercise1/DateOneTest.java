public class DateOneTest {

  public static void main(String args[]) {
    
    DateOne d = new DateOne();
    d.day = 17;
    d.month = 9;
    d.year = 1995;

    System.out.println(d.day + " " + d.month + " " + d.year);

  }// end main

} // end class

