public class DateFourTest {

  public static void main(String args[]) {

    DateFour d1 = new DateFour();
    DateFour d2 = new DateFour(3, 9, 1967);
  
    d1.display();
    d2.display();

  } // end main
} // end class
