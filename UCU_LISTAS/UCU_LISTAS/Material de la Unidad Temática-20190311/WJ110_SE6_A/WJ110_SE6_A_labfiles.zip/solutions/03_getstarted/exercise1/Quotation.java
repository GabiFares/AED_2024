public class Quotation {

  public String quote = "Welcome to Sun!";
    
  public void display() {

        System.out.println(quote);
  }
}
