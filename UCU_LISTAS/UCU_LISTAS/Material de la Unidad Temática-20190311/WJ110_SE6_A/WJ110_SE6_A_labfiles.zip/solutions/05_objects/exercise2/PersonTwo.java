public class PersonTwo {

  public String person = "Greg Brown";
  public String quote = "Its a messed up world, but I love it.";
    
  public void displayQuote() {
    
    System.out.println(quote);
    System.out.println("-" + person);

    } // end displayQuote
} // end class 
