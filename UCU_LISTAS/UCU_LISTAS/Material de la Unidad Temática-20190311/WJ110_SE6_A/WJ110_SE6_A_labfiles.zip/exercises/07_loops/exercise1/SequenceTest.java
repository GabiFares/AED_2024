class SequenceTest {
   
  public static void main (String args[]) {
 
    Sequence1 mySequence = new Sequence1();
  
  mySequence.displaySequence();

  } 
}
