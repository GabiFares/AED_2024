class Sequence2Test {

  public static void main (String args[]) {

    Sequence2 mySequence = new Sequence2();

    mySequence.displaySequence();

  }
}
