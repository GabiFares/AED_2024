class DiceTest {

  public static void main (String args[]) {

  Dice myDice = new Dice();

  myDice.throwDice();

  }
}
