public class ClockTest {
   
  public static void main (String args[]) {
 
    Clock myClock = new Clock();
  
    myClock.displayPartOfDay();

  } 
}
