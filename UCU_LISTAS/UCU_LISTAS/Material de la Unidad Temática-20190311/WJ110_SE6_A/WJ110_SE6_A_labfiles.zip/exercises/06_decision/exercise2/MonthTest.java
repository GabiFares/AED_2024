public class MonthTest {
   
  public static void main (String args[]) {
 
    Month myMonth = new Month();
  
    myMonth.displayMonth();

  } 
}
