public class Quotation {

  public String quote = "Welcome to Sun!";
    
  public void display() {

        /* Add code to display the value of the member variable. */
  }
}
