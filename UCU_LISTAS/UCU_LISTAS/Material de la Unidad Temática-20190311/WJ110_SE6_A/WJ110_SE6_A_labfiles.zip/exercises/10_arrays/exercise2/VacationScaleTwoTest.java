public class VacationScaleTwoTest {
   
  public static void main (String args[]) {
 
    VacationScaleTwo myVacationScaleTwo = new VacationScaleTwo();
  
    myVacationScaleTwo.setVacationScale();

    myVacationScaleTwo.displayVacationDays();

  } 
}
