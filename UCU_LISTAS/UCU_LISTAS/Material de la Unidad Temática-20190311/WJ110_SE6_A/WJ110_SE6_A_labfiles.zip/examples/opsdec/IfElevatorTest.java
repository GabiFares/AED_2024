public class IfElevatorTest {

   public static void main(String args[]) {
     
    IfElevator myIfElevator = new IfElevator();
     
     myIfElevator.openDoor();
     myIfElevator.closeDoor();
     myIfElevator.goDown();
     myIfElevator.goUp();
     myIfElevator.goUp();
     myIfElevator.goUp();
     myIfElevator.openDoor();
     myIfElevator.closeDoor();
     myIfElevator.goDown();
     myIfElevator.openDoor();
     myIfElevator.closeDoor();
     myIfElevator.goDown();
     myIfElevator.openDoor();
   }
}
