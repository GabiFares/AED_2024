public class SwitchDateTest {

   public static void main(String args[]) {
     
    SwitchDate mySwitchDate = new SwitchDate();

    mySwitchDate.calculateNumDays();
     
   }
}
