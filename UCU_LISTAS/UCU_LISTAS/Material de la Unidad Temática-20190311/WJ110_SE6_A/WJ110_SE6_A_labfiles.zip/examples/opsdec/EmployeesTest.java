public class EmployeesTest {

   public static void main(String args[]) {
     
    Employees myEmployees = new Employees();

    myEmployees.areNamesEqual();
    
   }
}
