public class NestedIfElevatorTest {

   public static void main(String args[]) {
     
    NestedIfElevator myNestedIfElevator = new NestedIfElevator();
     
     myNestedIfElevator.openDoor();
     myNestedIfElevator.closeDoor();
     myNestedIfElevator.goDown();
     myNestedIfElevator.goUp();
     myNestedIfElevator.goUp();
     myNestedIfElevator.goUp();
     myNestedIfElevator.openDoor();
     myNestedIfElevator.closeDoor();
     myNestedIfElevator.goDown();
     myNestedIfElevator.openDoor();
     myNestedIfElevator.closeDoor();
     myNestedIfElevator.goDown();
     myNestedIfElevator.openDoor();
   }
}
