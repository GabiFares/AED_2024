public class ArgsTest {
   
  public static void main (String args[]) {
 
    System.out.println("args[0] is " + args[0]);
    System.out.println("args[1] is " + args[1]);
  } 
}
