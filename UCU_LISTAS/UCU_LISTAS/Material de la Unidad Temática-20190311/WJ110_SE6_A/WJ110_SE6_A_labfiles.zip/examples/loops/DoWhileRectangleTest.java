public class DoWhileRectangleTest {

   public static void main(String args[]) {
     
    DoWhileRectangle myDoWhileRectangle = new DoWhileRectangle();

    myDoWhileRectangle.displayRectangle();
     
   }
}
