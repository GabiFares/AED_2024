public class ClothingTwoTest {
   
  public static void main (String args[]) {
 
  ShirtTwo myShirtTwo = new ShirtTwo();
  
  myShirtTwo.displayInformation();

  } 
}
