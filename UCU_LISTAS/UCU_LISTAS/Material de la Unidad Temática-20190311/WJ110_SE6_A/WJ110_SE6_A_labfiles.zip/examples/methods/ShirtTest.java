class ShirtTest {
   
  public static void main (String args[]) {
 
  Shirt myShirt = new Shirt();
  
  myShirt.display();

  } 
}
