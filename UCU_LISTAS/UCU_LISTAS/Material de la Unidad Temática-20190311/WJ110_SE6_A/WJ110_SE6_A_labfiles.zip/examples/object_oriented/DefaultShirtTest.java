class DefaultShirtTest {

  public static void main (String args[]) {

    DefaultShirt defShirt = new DefaultShirt();
    char colorCode;

    colorCode = defShirt.getColorCode();

    System.out.println("Color Code: " + colorCode);
  }
}
