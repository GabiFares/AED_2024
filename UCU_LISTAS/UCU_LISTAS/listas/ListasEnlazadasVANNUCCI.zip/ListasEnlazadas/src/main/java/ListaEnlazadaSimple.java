/**
 *
 * @author ColoVannucci.F
 */
public class ListaEnlazadaSimple {
    private Nodo cabeza;//Primer elemento de la Lista
    private int tamaño;
    /**
     * Constructor de la Lista Enlazada
     */
    public ListaEnlazadaSimple(){
        cabeza = null;//Sin valor(nodo) inicial
        tamaño = 0;
    }
    /**
     * Imprime todos los valores de la Lista
     */
    public void mostrarListaEnlazada(){
        if(!(estaVacia())){
            //Recorre e imprime todos los nodos de la lista
            for(int i = 0;i < tamaño;i++){
                System.out.println(obtenerNodo(i));
            }
        }
    }
    /**
     * Añadimos un elemento como cabeza de la Lista
     * @param nodoDado 
     */
    public void añadirPrimero(Nodo nodoDado){
        if(estaVacia()){
            //Si esta vacia simplemente lo agrega como cabezal
            cabeza = nodoDado;
        }else{
            //Almacena el Primer Nodo de la lista (cabezal)
            Nodo nodoTemporal = cabeza;
            //Referenciamos al Primer Nodo DESPUES del Nuevo Nodo
            nodoDado.enlazarSiguiente(nodoTemporal);
            //Definimos que el Cabezal(Primer objeto de la lista) ahora es el Nuevo Nodo
            cabeza = nodoDado;
        }
        tamaño++;
    }
    /**
     * Cambiamos el cabezal referenciando al segundo elemento de la lista
     */
    public void eliminarPrimero(){
        //Referencia el cabezal al siguiente elemento perdiendo(olvidando) el anterior
        cabeza = cabeza.obtenerSiguiente();
        tamaño--;
    }
    /**
     * Añadimos un Nodo en cualquier posicion dentro de la lista
     * @param nodoDado
     * @param indice 
     */
    public void añadirDentroLista(Nodo nodoDado, int indice){
        if(estaDentroLista(indice)){
            int contador = 0;
            Nodo nodoAnterior = null;
            Nodo nodoTemporal = cabeza;
            //Busca el anterior del que queremos eliminar
            while(contador < indice && nodoTemporal.obtenerSiguiente() != null){
                //Obtenemos el nodo que apunta al lugar posicionado en el indice
                if(contador == indice - 2){
                    nodoAnterior = nodoTemporal.obtenerSiguiente();
                }
                nodoTemporal = nodoTemporal.obtenerSiguiente();
                contador++;
            }
            //Enlazamos al nodo anterior el que vamos a añadir
            nodoAnterior.enlazarSiguiente(nodoDado);
            //Enlazamos el resto de la lista al nodo nuevo
            nodoDado.enlazarSiguiente(nodoTemporal);
            tamaño++;
        }
    }
    /**
     * Elimina los valores de la lista desde el indice dado hasta el final
     * @param indice 
     */
    public void cortarLista(int indice){
        if(estaDentroLista(indice)){
            int contador = 0;
            Nodo nodoTemporal = cabeza;
            //Busca el anterior del que queremos eliminar
            while(contador < indice && nodoTemporal.obtenerSiguiente() != null){
                nodoTemporal = nodoTemporal.obtenerSiguiente();
                contador++;
            }
            /*
            Luego de ese Nodo no lo enlazamos a ningun otro,
            eliminamos todos los otros Nodos que iban seguidos a ese
            */
            nodoTemporal.enlazarSiguiente(null);
            tamaño = indice;
        }
    }
    /**
     * Eliminamos la referencia al nodo que queremos quitar de la lista
     * @param indice 
     */
    public void eliminarNodo(int indice){
        if(estaDentroLista(indice)){
            int contador = 0;
            Nodo nodoTemporal = cabeza;
            //Busca el anterior del que queremos eliminar
            while(contador < indice - 1 && nodoTemporal.obtenerSiguiente() != null){
                nodoTemporal = nodoTemporal.obtenerSiguiente();
                contador++;
            }
            //Saltandose el que tenia seguido de él, Enlaza al siguiente del que queremos eliminar
            nodoTemporal.enlazarSiguiente(nodoTemporal.obtenerSiguiente().obtenerSiguiente());
            tamaño--;
        }
    }
    /**
     * Obtener Nodo en el lugar deseado
     * @param indice
     * @return 
     */
    public Object obtenerNodo(int indice){
        if(estaDentroLista(indice)){
            int contador = 0;
            Nodo nodoTemporal = cabeza;
            while(contador < indice && nodoTemporal.obtenerSiguiente() != null){
                //Cambia de un enlaze a otro
                nodoTemporal = nodoTemporal.obtenerSiguiente();
                contador++;
            }
            return nodoTemporal.obtenerValor();
        }
        return null;
    }
    /**
     * Devuelve el Tamaño de la Lista
     * @return 
     */
    public int tamañoLista(){
        return tamaño;
    }
    /**
     * Verifica si la Lista está vacia
     * @return 
     */
    public boolean estaVacia(){
        return cabeza == null;
    }
    /**
     * Verifica si el indice deseado es un valor dentro de la lista
     * @param indice
     * @return 
     */
    private boolean estaDentroLista(int indice){
        return indice < tamaño && indice >= 0;
    }
}
