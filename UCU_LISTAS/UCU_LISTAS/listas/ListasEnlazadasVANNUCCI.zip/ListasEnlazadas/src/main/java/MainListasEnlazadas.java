/**
 *
 * @author ColoVannucci.F
 */
public class MainListasEnlazadas {
    public static void main(String[] args) {
        
        Nodo primero = new Nodo("hola");
        Nodo segundo = new Nodo("como");
        Nodo tercero = new Nodo("estas");
        Nodo cuarto = new Nodo("007");
        Nodo quinto = new Nodo("que");
        Nodo sexto = new Nodo("hiciste");
        
        //primero.enlazarSiguiente(segundo);
        
        //primero.obtenerSiguiente().enlazarSiguiente(tercero);
        
        //System.out.println(primero.obtenerSiguiente().obtenerValor().toString());
        
        ListaEnlazadaSimple listaNodos = new ListaEnlazadaSimple();
        
        System.out.println("Esta vacia?: "+ listaNodos.estaVacia());
        
        listaNodos.añadirPrimero(primero);
        listaNodos.añadirPrimero(segundo);
        listaNodos.añadirPrimero(tercero);
        listaNodos.añadirPrimero(cuarto);
        listaNodos.añadirPrimero(quinto);
        listaNodos.añadirPrimero(sexto);
        
        System.out.println("Tamaño: "+ listaNodos.tamañoLista());
        listaNodos.mostrarListaEnlazada();
        
        System.out.println("Primer Elemento: "+ listaNodos.obtenerNodo(0));
        System.out.println("Ultimo: "+ listaNodos.obtenerNodo(listaNodos.tamañoLista() - 1));
        System.out.println("Nodo Indice 2: "+ listaNodos.obtenerNodo(2));
        
        System.out.println("Esta vacia?: "+ listaNodos.estaVacia());
        System.out.println("Tamaño: "+ listaNodos.tamañoLista());
        
        //listaNodos.eliminarNodo(3);
        //listaNodos.cortarLista(4);
        //listaNodos.eliminarPrimero();
        
        System.out.println("Ultimo: "+ listaNodos.obtenerNodo(listaNodos.tamañoLista() - 1));
        System.out.println("Tamaño: "+ listaNodos.tamañoLista());
        
        Nodo septimo = new Nodo("añadido");
        listaNodos.añadirDentroLista(septimo, 2);
        
        listaNodos.mostrarListaEnlazada();
    }
    
}
